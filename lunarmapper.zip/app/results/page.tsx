"use client"

import { useState, Suspense, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Slider } from "@/components/ui/slider"
import { Download, Moon, ArrowLeft, Eye, BarChart3, Share2, Settings, Maximize, Palette } from "lucide-react"
import Link from "next/link"
import { Canvas } from "@react-three/fiber"
import { OrbitControls, PerspectiveCamera } from "@react-three/drei"
import * as THREE from "three"

// 3D Terrain Component
function TerrainMesh() {
  // Create a heightmap-based geometry
  const geometry = new THREE.PlaneGeometry(10, 10, 128, 128)
  const vertices = geometry.attributes.position.array as Float32Array

  // Generate realistic lunar terrain heights
  for (let i = 0; i < vertices.length; i += 3) {
    const x = vertices[i]
    const y = vertices[i + 1]

    // Create crater-like features
    const crater1 = Math.exp(-((x - 2) ** 2 + (y - 1) ** 2) * 2) * -2
    const crater2 = Math.exp(-((x + 1) ** 2 + (y + 2) ** 2) * 1.5) * -1.5
    const crater3 = Math.exp(-((x - 1) ** 2 + (y - 3) ** 2) * 3) * -1

    // Add some random noise for surface roughness
    const noise = (Math.random() - 0.5) * 0.2

    vertices[i + 2] = crater1 + crater2 + crater3 + noise
  }

  geometry.computeVertexNormals()

  return (
    <mesh geometry={geometry} rotation={[-Math.PI / 2, 0, 0]}>
      <meshStandardMaterial color="#8B7355" roughness={0.8} metalness={0.1} wireframe={false} />
    </mesh>
  )
}

function Scene3D() {
  return (
    <>
      <PerspectiveCamera makeDefault position={[5, 5, 5]} />
      <OrbitControls enablePan={true} enableZoom={true} enableRotate={true} />
      <ambientLight intensity={0.4} />
      <directionalLight position={[10, 10, 5]} intensity={1} />
      <TerrainMesh />
      <gridHelper args={[20, 20]} />
    </>
  )
}

export default function ResultsPage() {
  const [elevationRange, setElevationRange] = useState([0, 100])
  const [colorScheme, setColorScheme] = useState("terrain")
  const [wireframe, setWireframe] = useState(false)

  const [uploadedImage, setUploadedImage] = useState<string | null>(null)
  const [fileName, setFileName] = useState<string>("")
  const [fileSize, setFileSize] = useState<string>("")

  useEffect(() => {
    const imageData = sessionStorage.getItem("uploadedImage")
    const name = sessionStorage.getItem("uploadedFileName")
    const size = sessionStorage.getItem("uploadedFileSize")

    if (imageData) setUploadedImage(imageData)
    if (name) setFileName(name)
    if (size) setFileSize(size)
  }, [])

  const demStats = {
    resolution: "0.8m/pixel",
    elevationRange: "-2.3m to +1.8m",
    accuracy: "98.7%",
    processingTime: "8.3 minutes",
    fileSize: "24.7 MB",
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800">
      {/* Navigation */}
      <nav className="border-b border-blue-500/20 bg-slate-900/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/upload" className="flex items-center space-x-2 text-blue-300 hover:text-blue-200">
                <ArrowLeft className="h-5 w-5" />
                <span>New Upload</span>
              </Link>
              <div className="flex items-center space-x-2">
                <Moon className="h-8 w-8 text-blue-400" />
                <span className="text-2xl font-bold text-white">LunarMapper</span>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="outline" className="border-blue-500/30 text-blue-300 bg-transparent">
                <Share2 className="h-4 w-4 mr-2" />
                Share
              </Button>
              <Button className="bg-gradient-to-r from-blue-500 to-orange-500 hover:from-blue-600 hover:to-orange-600">
                <Download className="h-4 w-4 mr-2" />
                Download DEM
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        <div className="space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <Badge className="bg-green-500/20 text-green-300 border-green-500/30">Processing Complete</Badge>
            <h1 className="text-4xl font-bold text-white">Digital Elevation Model</h1>
            <p className="text-xl text-blue-200">High-resolution lunar terrain generated from your image</p>
          </div>

          {/* Main Content */}
          <div className="grid lg:grid-cols-3 gap-8">
            {/* 3D Viewer */}
            <div className="lg:col-span-2">
              <Card className="bg-slate-800/50 border-blue-500/20 h-[600px]">
                <CardHeader className="pb-4">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-white flex items-center gap-2">
                      <Eye className="h-5 w-5" />
                      3D Terrain Model
                    </CardTitle>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setWireframe(!wireframe)}
                        className="border-blue-500/30 text-blue-300"
                      >
                        <Settings className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm" className="border-blue-500/30 text-blue-300 bg-transparent">
                        <Maximize className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-0 h-[500px]">
                  <Canvas className="w-full h-full bg-slate-900 rounded-b-lg">
                    <Suspense fallback={null}>
                      <Scene3D />
                    </Suspense>
                  </Canvas>
                </CardContent>
              </Card>
            </div>

            {/* Controls & Stats */}
            <div className="space-y-6">
              {/* DEM Statistics */}
              <Card className="bg-slate-800/50 border-blue-500/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <BarChart3 className="h-5 w-5" />
                    DEM Statistics
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-blue-200 text-sm">Resolution</p>
                      <p className="text-white font-semibold">{demStats.resolution}</p>
                    </div>
                    <div>
                      <p className="text-blue-200 text-sm">Accuracy</p>
                      <p className="text-green-400 font-semibold">{demStats.accuracy}</p>
                    </div>
                    <div>
                      <p className="text-blue-200 text-sm">Elevation Range</p>
                      <p className="text-white font-semibold">{demStats.elevationRange}</p>
                    </div>
                    <div>
                      <p className="text-blue-200 text-sm">File Size</p>
                      <p className="text-white font-semibold">{demStats.fileSize}</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-blue-200 text-sm">Processing Time</p>
                    <p className="text-orange-400 font-semibold">{demStats.processingTime}</p>
                  </div>
                </CardContent>
              </Card>

              {/* Visualization Controls */}
              <Card className="bg-slate-800/50 border-blue-500/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Palette className="h-5 w-5" />
                    Visualization
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-blue-200 text-sm">Elevation Range</label>
                    <Slider
                      value={elevationRange}
                      onValueChange={setElevationRange}
                      max={100}
                      min={0}
                      step={1}
                      className="w-full"
                    />
                    <div className="flex justify-between text-xs text-blue-300">
                      <span>{elevationRange[0]}%</span>
                      <span>{elevationRange[1]}%</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-blue-200 text-sm">Color Scheme</label>
                    <div className="grid grid-cols-2 gap-2">
                      {["terrain", "elevation", "slope", "aspect"].map((scheme) => (
                        <Button
                          key={scheme}
                          variant={colorScheme === scheme ? "default" : "outline"}
                          size="sm"
                          onClick={() => setColorScheme(scheme)}
                          className={
                            colorScheme === scheme
                              ? "bg-blue-500 hover:bg-blue-600"
                              : "border-blue-500/30 text-blue-300"
                          }
                        >
                          {scheme.charAt(0).toUpperCase() + scheme.slice(1)}
                        </Button>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Download Options */}
              <Card className="bg-slate-800/50 border-blue-500/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Download className="h-5 w-5" />
                    Download Options
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button className="w-full bg-gradient-to-r from-blue-500 to-orange-500 hover:from-blue-600 hover:to-orange-600">
                    GeoTIFF DEM (24.7 MB)
                  </Button>
                  <Button variant="outline" className="w-full border-blue-500/30 text-blue-300 bg-transparent">
                    3D Model (OBJ)
                  </Button>
                  <Button variant="outline" className="w-full border-blue-500/30 text-blue-300 bg-transparent">
                    Analysis Report (PDF)
                  </Button>
                  <Button variant="outline" className="w-full border-blue-500/30 text-blue-300 bg-transparent">
                    Raw Data (CSV)
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Additional Analysis */}
          <Tabs defaultValue="original" className="w-full">
            <TabsList className="grid w-full grid-cols-5 bg-slate-800/50">
              <TabsTrigger value="original" className="data-[state=active]:bg-blue-500/20">
                Original Image
              </TabsTrigger>
              <TabsTrigger value="elevation" className="data-[state=active]:bg-blue-500/20">
                Elevation Profile
              </TabsTrigger>
              <TabsTrigger value="slope" className="data-[state=active]:bg-blue-500/20">
                Slope Analysis
              </TabsTrigger>
              <TabsTrigger value="comparison" className="data-[state=active]:bg-blue-500/20">
                Validation
              </TabsTrigger>
              <TabsTrigger value="metadata" className="data-[state=active]:bg-blue-500/20">
                Metadata
              </TabsTrigger>
            </TabsList>

            <TabsContent value="original" className="mt-6">
              <Card className="bg-slate-800/50 border-blue-500/20">
                <CardHeader>
                  <CardTitle className="text-white">Original Lunar Image</CardTitle>
                </CardHeader>
                <CardContent>
                  {uploadedImage ? (
                    <div className="space-y-4">
                      <img
                        src={uploadedImage || "/placeholder.svg"}
                        alt="Uploaded lunar surface"
                        className="w-full max-w-2xl mx-auto rounded-lg border border-blue-500/20"
                      />
                      <div className="text-center space-y-2">
                        <p className="text-blue-200">File: {fileName}</p>
                        <p className="text-blue-200">Size: {fileSize} MB</p>
                        <Badge className="bg-green-500/20 text-green-300">Successfully Processed</Badge>
                      </div>
                    </div>
                  ) : (
                    <div className="h-64 bg-slate-700/30 rounded-lg flex items-center justify-center">
                      <p className="text-blue-200">No image data available</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="elevation" className="mt-6">
              <Card className="bg-slate-800/50 border-blue-500/20">
                <CardHeader>
                  <CardTitle className="text-white">Elevation Profile Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 bg-slate-700/30 rounded-lg flex items-center justify-center">
                    <p className="text-blue-200">Interactive elevation profile chart would be displayed here</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="slope" className="mt-6">
              <Card className="bg-slate-800/50 border-blue-500/20">
                <CardHeader>
                  <CardTitle className="text-white">Slope Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 bg-slate-700/30 rounded-lg flex items-center justify-center">
                    <p className="text-blue-200">Slope gradient analysis and statistics would be displayed here</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="comparison" className="mt-6">
              <Card className="bg-slate-800/50 border-blue-500/20">
                <CardHeader>
                  <CardTitle className="text-white">Validation Against Reference Data</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 bg-slate-700/30 rounded-lg flex items-center justify-center">
                    <p className="text-blue-200">Comparison with LOLA/LRO reference data would be displayed here</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="metadata" className="mt-6">
              <Card className="bg-slate-800/50 border-blue-500/20">
                <CardHeader>
                  <CardTitle className="text-white">Processing Metadata</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-6 text-sm">
                    <div className="space-y-3">
                      <div>
                        <p className="text-blue-200">Input Image</p>
                        <p className="text-white">lunar_surface_001.tif</p>
                      </div>
                      <div>
                        <p className="text-blue-200">Solar Zenith Angle</p>
                        <p className="text-white">45.2°</p>
                      </div>
                      <div>
                        <p className="text-blue-200">Solar Azimuth Angle</p>
                        <p className="text-white">120.8°</p>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <div>
                        <p className="text-blue-200">U-Net Model Version</p>
                        <p className="text-white">v2.1.3</p>
                      </div>
                      <div>
                        <p className="text-blue-200">Processing Date</p>
                        <p className="text-white">{new Date().toLocaleDateString()}</p>
                      </div>
                      <div>
                        <p className="text-blue-200">Coordinate System</p>
                        <p className="text-white">Moon 2000</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
