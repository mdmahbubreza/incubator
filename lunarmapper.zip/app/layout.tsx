import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "LunarMapper - Turn Shadows into Elevation",
  description: "High-Resolution Lunar DEMs from Single Images using AI-powered photoclinometry",
  keywords: "lunar mapping, DEM, digital elevation model, photoclinometry, U-Net, CNN, moon, NASA",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className="dark">
      <body className={inter.className}>{children}</body>
    </html>
  )
}
