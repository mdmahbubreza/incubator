"use client"

import type React from "react"

import { useState, useCallback, Suspense, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Slider } from "@/components/ui/slider"
import {
  Upload,
  Moon,
  ArrowLeft,
  CheckCircle,
  Zap,
  Brain,
  Globe,
  Eye,
  Settings,
  Download,
  BarChart3,
  Palette,
} from "lucide-react"
import Link from "next/link"
import { Canvas } from "@react-three/fiber"
import { OrbitControls, PerspectiveCamera } from "@react-three/drei"
import * as THREE from "three"

// 3D Terrain Component
function TerrainMesh() {
  const geometry = new THREE.PlaneGeometry(10, 10, 128, 128)
  const vertices = geometry.attributes.position.array as Float32Array

  for (let i = 0; i < vertices.length; i += 3) {
    const x = vertices[i]
    const y = vertices[i + 1]

    const crater1 = Math.exp(-((x - 2) ** 2 + (y - 1) ** 2) * 2) * -2
    const crater2 = Math.exp(-((x + 1) ** 2 + (y + 2) ** 2) * 1.5) * -1.5
    const crater3 = Math.exp(-((x - 1) ** 2 + (y - 3) ** 2) * 3) * -1
    const noise = (Math.random() - 0.5) * 0.2

    vertices[i + 2] = crater1 + crater2 + crater3 + noise
  }

  geometry.computeVertexNormals()

  return (
    <mesh geometry={geometry} rotation={[-Math.PI / 2, 0, 0]}>
      <meshStandardMaterial color="#8B7355" roughness={0.8} metalness={0.1} />
    </mesh>
  )
}

function Scene3D() {
  return (
    <>
      <PerspectiveCamera makeDefault position={[5, 5, 5]} />
      <OrbitControls enablePan={true} enableZoom={true} enableRotate={true} />
      <ambientLight intensity={0.4} />
      <directionalLight position={[10, 10, 5]} intensity={1} />
      <TerrainMesh />
      <gridHelper args={[20, 20]} />
    </>
  )
}

interface UploadedFile {
  file: File
  preview: string
}

export default function ProcessPage() {
  const [uploadedFile, setUploadedFile] = useState<UploadedFile | null>(null)
  const [processing, setProcessing] = useState(false)
  const [processingStep, setProcessingStep] = useState(0)
  const [processingComplete, setProcessingComplete] = useState(false)
  const [dragActive, setDragActive] = useState(false)
  const [elevationRange, setElevationRange] = useState([0, 100])

  // Cleanup object URLs when component unmounts
  useEffect(() => {
    return () => {
      if (uploadedFile?.preview) {
        URL.revokeObjectURL(uploadedFile.preview)
      }
    }
  }, [uploadedFile?.preview])

  const processingSteps = [
    { name: "Image Validation", icon: CheckCircle, description: "Validating image format and quality" },
    { name: "Metadata Analysis", icon: Settings, description: "Processing solar angles and geometry" },
    { name: "U-Net CNN Processing", icon: Brain, description: "Deep learning feature extraction" },
    { name: "DEM Generation", icon: Globe, description: "Converting features to elevation model" },
    { name: "3D Model Creation", icon: Eye, description: "Generating interactive visualization" },
  ]

  const demStats = {
    resolution: "0.8m/pixel",
    elevationRange: "-2.3m to +1.8m",
    accuracy: "98.7%",
    processingTime: "8.3 minutes",
    fileSize: "24.7 MB",
  }

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
  }, [])

  const handleDragIn = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(true)
  }, [])

  const handleDragOut = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)
  }, [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)

    const files = e.dataTransfer.files
    if (files && files.length > 0) {
      const file = files[0]
      handleFile(file)
    }
  }, [])

  const handleFile = useCallback((file: File) => {
    // Validate file type
    const validTypes = ["image/jpeg", "image/jpg", "image/png", "image/tiff", "image/tif"]

    if (!validTypes.includes(file.type.toLowerCase())) {
      alert("Please upload a valid image file (JPG, PNG, TIFF)")
      return
    }

    // Validate file size (max 50MB)
    const maxSize = 50 * 1024 * 1024 // 50MB
    if (file.size > maxSize) {
      alert("File size must be less than 50MB")
      return
    }

    const preview = URL.createObjectURL(file)
    setUploadedFile({ file, preview })
    setProcessingComplete(false)
  }, [])

  const handleFileInput = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const files = e.target.files
      if (files && files.length > 0) {
        handleFile(files[0])
      }
      // Reset input value to allow same file to be selected again
      e.target.value = ""
    },
    [handleFile],
  )

  const startProcessing = async () => {
    setProcessing(true)
    setProcessingStep(0)
    setProcessingComplete(false)

    // Simulate processing steps
    for (let i = 0; i < processingSteps.length; i++) {
      setProcessingStep(i)
      await new Promise((resolve) => setTimeout(resolve, 1500))
    }

    setProcessing(false)
    setProcessingComplete(true)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800">
      {/* Navigation */}
      <nav className="border-b border-blue-500/20 bg-slate-900/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/" className="flex items-center space-x-2 text-blue-300 hover:text-blue-200">
                <ArrowLeft className="h-5 w-5" />
                <span>Home</span>
              </Link>
              <div className="flex items-center space-x-2">
                <Moon className="h-8 w-8 text-blue-400" />
                <span className="text-2xl font-bold text-white">LunarMapper</span>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        <div className="space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <h1 className="text-4xl font-bold text-white">Lunar DEM Generator</h1>
            <p className="text-xl text-blue-200">Upload your lunar image and generate a Digital Elevation Model</p>
          </div>

          {!processingComplete ? (
            <div className="max-w-4xl mx-auto space-y-8">
              {/* Upload Section */}
              <Card className="bg-slate-800/50 border-blue-500/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Upload className="h-5 w-5" />
                    Upload Lunar Image
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div
                    className={`border-2 border-dashed rounded-lg p-12 text-center transition-colors cursor-pointer ${
                      dragActive
                        ? "border-blue-400 bg-blue-500/10"
                        : "border-blue-500/30 hover:border-blue-400 hover:bg-blue-500/5"
                    }`}
                    onDragEnter={handleDragIn}
                    onDragLeave={handleDragOut}
                    onDragOver={handleDrag}
                    onDrop={handleDrop}
                    onClick={() => document.getElementById("file-upload")?.click()}
                  >
                    {uploadedFile ? (
                      <div className="space-y-4">
                        <img
                          src={uploadedFile.preview || "/placeholder.svg"}
                          alt="Uploaded lunar image"
                          className="max-w-md max-h-64 mx-auto rounded-lg object-contain"
                          onLoad={() => URL.revokeObjectURL(uploadedFile.preview)}
                        />
                        <div className="space-y-2">
                          <p className="text-white font-medium">{uploadedFile.file.name}</p>
                          <p className="text-blue-200 text-sm">
                            {(uploadedFile.file.size / 1024 / 1024).toFixed(2)} MB • {uploadedFile.file.type}
                          </p>
                          <Badge className="bg-green-500/20 text-green-300 border-green-500/30">
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Ready to Process
                          </Badge>
                          <div className="mt-4">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation()
                                setUploadedFile(null)
                              }}
                              className="border-red-500/30 text-red-300 hover:bg-red-500/10"
                            >
                              Remove Image
                            </Button>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <Upload className="h-16 w-16 text-blue-400 mx-auto" />
                        <div>
                          <p className="text-xl text-white mb-2">Drag and drop your lunar image here</p>
                          <p className="text-blue-200 mb-4">Supports JPG, PNG, TIFF formats • Max 50MB</p>
                          <input
                            type="file"
                            accept="image/jpeg,image/jpg,image/png,image/tiff,image/tif"
                            onChange={handleFileInput}
                            className="hidden"
                            id="file-upload"
                          />
                          <Button
                            type="button"
                            onClick={(e) => e.stopPropagation()}
                            className="bg-gradient-to-r from-blue-500 to-orange-500 hover:from-blue-600 hover:to-orange-600"
                          >
                            Choose File
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Quick Metadata */}
              {uploadedFile && (
                <Card className="bg-slate-800/50 border-blue-500/20">
                  <CardHeader>
                    <CardTitle className="text-white">Optional: Image Metadata</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="solar-angle" className="text-blue-200">
                          Solar Angle (°)
                        </Label>
                        <Input
                          id="solar-angle"
                          placeholder="45.0"
                          className="bg-slate-700/50 border-blue-500/30 text-white"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="coordinates" className="text-blue-200">
                          Coordinates
                        </Label>
                        <Input
                          id="coordinates"
                          placeholder="Lat, Lon"
                          className="bg-slate-700/50 border-blue-500/30 text-white"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="mission" className="text-blue-200">
                          Mission
                        </Label>
                        <Input
                          id="mission"
                          placeholder="LRO NAC"
                          className="bg-slate-700/50 border-blue-500/30 text-white"
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Process Button */}
              {uploadedFile && (
                <div className="text-center">
                  <Button
                    size="lg"
                    onClick={startProcessing}
                    disabled={processing}
                    className="bg-gradient-to-r from-blue-500 to-orange-500 hover:from-blue-600 hover:to-orange-600 px-8 py-3"
                  >
                    {processing ? "Processing..." : "Generate DEM"}
                    <Zap className="ml-2 h-5 w-5" />
                  </Button>
                </div>
              )}

              {/* Processing Status */}
              {processing && (
                <Card className="bg-slate-800/50 border-blue-500/20">
                  <CardContent className="p-8 space-y-6">
                    <div className="text-center">
                      <h3 className="text-2xl font-bold text-white mb-2">Processing Your Image</h3>
                      <p className="text-blue-200">AI is analyzing your lunar image and generating the DEM</p>
                    </div>

                    <div className="space-y-4">
                      {processingSteps.map((step, index) => {
                        const Icon = step.icon
                        const isActive = index === processingStep
                        const isCompleted = index < processingStep

                        return (
                          <div
                            key={step.name}
                            className={`flex items-center space-x-4 p-4 rounded-lg transition-colors ${
                              isActive
                                ? "bg-blue-500/20 border border-blue-500/30"
                                : isCompleted
                                  ? "bg-green-500/10 border border-green-500/20"
                                  : "bg-slate-700/30"
                            }`}
                          >
                            <Icon
                              className={`h-6 w-6 ${
                                isActive
                                  ? "text-blue-400 animate-pulse"
                                  : isCompleted
                                    ? "text-green-400"
                                    : "text-slate-400"
                              }`}
                            />
                            <div className="flex-1">
                              <h3
                                className={`font-medium ${isActive || isCompleted ? "text-white" : "text-slate-400"}`}
                              >
                                {step.name}
                              </h3>
                              <p
                                className={`text-sm ${
                                  isActive ? "text-blue-200" : isCompleted ? "text-green-200" : "text-slate-500"
                                }`}
                              >
                                {step.description}
                              </p>
                            </div>
                            {isCompleted && <CheckCircle className="h-5 w-5 text-green-400" />}
                          </div>
                        )
                      })}
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-blue-200">Progress</span>
                        <span className="text-blue-200">
                          {Math.round((processingStep / processingSteps.length) * 100)}%
                        </span>
                      </div>
                      <Progress value={(processingStep / processingSteps.length) * 100} className="h-2 bg-slate-700" />
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          ) : (
            /* Results Section */
            <div className="space-y-8">
              <div className="text-center space-y-4">
                <Badge className="bg-green-500/20 text-green-300 border-green-500/30">Processing Complete</Badge>
                <h2 className="text-4xl font-bold text-white">Digital Elevation Model Generated</h2>
                <p className="text-xl text-blue-200">Your lunar terrain model is ready</p>
              </div>

              <div className="grid lg:grid-cols-3 gap-8">
                {/* 3D Viewer */}
                <div className="lg:col-span-2">
                  <Card className="bg-slate-800/50 border-blue-500/20 h-[600px]">
                    <CardHeader className="pb-4">
                      <CardTitle className="text-white flex items-center gap-2">
                        <Eye className="h-5 w-5" />
                        3D Terrain Model
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-0 h-[500px]">
                      <Canvas className="w-full h-full bg-slate-900 rounded-b-lg">
                        <Suspense fallback={null}>
                          <Scene3D />
                        </Suspense>
                      </Canvas>
                    </CardContent>
                  </Card>
                </div>

                {/* Stats & Controls */}
                <div className="space-y-6">
                  {/* DEM Statistics */}
                  <Card className="bg-slate-800/50 border-blue-500/20">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center gap-2">
                        <BarChart3 className="h-5 w-5" />
                        DEM Statistics
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-blue-200 text-sm">Resolution</p>
                          <p className="text-white font-semibold">{demStats.resolution}</p>
                        </div>
                        <div>
                          <p className="text-blue-200 text-sm">Accuracy</p>
                          <p className="text-green-400 font-semibold">{demStats.accuracy}</p>
                        </div>
                        <div>
                          <p className="text-blue-200 text-sm">Elevation Range</p>
                          <p className="text-white font-semibold">{demStats.elevationRange}</p>
                        </div>
                        <div>
                          <p className="text-blue-200 text-sm">File Size</p>
                          <p className="text-white font-semibold">{demStats.fileSize}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Visualization Controls */}
                  <Card className="bg-slate-800/50 border-blue-500/20">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center gap-2">
                        <Palette className="h-5 w-5" />
                        Visualization
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <label className="text-blue-200 text-sm">Elevation Range</label>
                        <Slider
                          value={elevationRange}
                          onValueChange={setElevationRange}
                          max={100}
                          min={0}
                          step={1}
                          className="w-full"
                        />
                      </div>
                    </CardContent>
                  </Card>

                  {/* Download Options */}
                  <Card className="bg-slate-800/50 border-blue-500/20">
                    <CardHeader>
                      <CardTitle className="text-white flex items-center gap-2">
                        <Download className="h-5 w-5" />
                        Download
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <Button className="w-full bg-gradient-to-r from-blue-500 to-orange-500 hover:from-blue-600 hover:to-orange-600">
                        GeoTIFF DEM
                      </Button>
                      <Button variant="outline" className="w-full border-blue-500/30 text-blue-300 bg-transparent">
                        3D Model (OBJ)
                      </Button>
                      <Button variant="outline" className="w-full border-blue-500/30 text-blue-300 bg-transparent">
                        Analysis Report
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Original vs Result */}
              <Tabs defaultValue="comparison" className="w-full">
                <TabsList className="grid w-full grid-cols-2 bg-slate-800/50">
                  <TabsTrigger value="comparison" className="data-[state=active]:bg-blue-500/20">
                    Before & After
                  </TabsTrigger>
                  <TabsTrigger value="analysis" className="data-[state=active]:bg-blue-500/20">
                    Analysis
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="comparison" className="mt-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <Card className="bg-slate-800/50 border-blue-500/20">
                      <CardHeader>
                        <CardTitle className="text-white">Original Image</CardTitle>
                      </CardHeader>
                      <CardContent>
                        {uploadedFile && (
                          <img
                            src={uploadedFile.preview || "/placeholder.svg"}
                            alt="Original lunar image"
                            className="w-full rounded-lg"
                          />
                        )}
                      </CardContent>
                    </Card>

                    <Card className="bg-slate-800/50 border-blue-500/20">
                      <CardHeader>
                        <CardTitle className="text-white">Generated DEM</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="aspect-square bg-gradient-to-br from-blue-900 to-orange-900 rounded-lg flex items-center justify-center">
                          <p className="text-white">DEM Visualization</p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                <TabsContent value="analysis" className="mt-6">
                  <Card className="bg-slate-800/50 border-blue-500/20">
                    <CardHeader>
                      <CardTitle className="text-white">Processing Analysis</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid md:grid-cols-2 gap-6 text-sm">
                        <div className="space-y-3">
                          <div>
                            <p className="text-blue-200">U-Net Model</p>
                            <p className="text-white">Lunar-CNN-v2.1.3</p>
                          </div>
                          <div>
                            <p className="text-blue-200">Processing Time</p>
                            <p className="text-white">{demStats.processingTime}</p>
                          </div>
                          <div>
                            <p className="text-blue-200">Features Detected</p>
                            <p className="text-white">3 craters, 12 ridges</p>
                          </div>
                        </div>
                        <div className="space-y-3">
                          <div>
                            <p className="text-blue-200">Confidence Score</p>
                            <p className="text-green-400">94.2%</p>
                          </div>
                          <div>
                            <p className="text-blue-200">Shadow Analysis</p>
                            <p className="text-white">High contrast detected</p>
                          </div>
                          <div>
                            <p className="text-blue-200">Terrain Type</p>
                            <p className="text-white">Highland crater field</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>

              {/* Process Another Image */}
              <div className="text-center">
                <Button
                  onClick={() => {
                    setUploadedFile(null)
                    setProcessingComplete(false)
                    setProcessing(false)
                    setProcessingStep(0)
                  }}
                  variant="outline"
                  className="border-blue-500/30 text-blue-300 bg-transparent"
                >
                  Process Another Image
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
