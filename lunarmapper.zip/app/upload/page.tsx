"use client"

import type React from "react"

import { useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Upload, Moon, ArrowLeft, CheckCircle, Zap, Brain, Globe, Eye, Settings } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

interface UploadedFile {
  file: File
  preview: string
  metadata?: {
    solarZenith: string
    solarAzimuth: string
    viewingAngle: string
    coordinates: string
    mission: string
  }
}

export default function UploadPage() {
  const router = useRouter()
  const [uploadedFile, setUploadedFile] = useState<UploadedFile | null>(null)
  const [processing, setProcessing] = useState(false)
  const [processingStep, setProcessingStep] = useState(0)
  const [dragActive, setDragActive] = useState(false)

  const processingSteps = [
    { name: "Image Validation", icon: CheckCircle, description: "Validating image format and quality" },
    { name: "Metadata Analysis", icon: Settings, description: "Processing solar angles and geometry" },
    { name: "U-Net CNN Processing", icon: Brain, description: "Deep learning feature extraction" },
    { name: "DEM Generation", icon: Globe, description: "Converting features to elevation model" },
    { name: "3D Model Creation", icon: Eye, description: "Generating interactive visualization" },
  ]

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }, [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0])
    }
  }, [])

  const handleFile = (file: File) => {
    if (file.type.startsWith("image/")) {
      const preview = URL.createObjectURL(file)
      setUploadedFile({ file, preview })
    }
  }

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0])
    }
  }

  const handleMetadataSubmit = (metadata: any) => {
    if (uploadedFile) {
      setUploadedFile({ ...uploadedFile, metadata })
    }
  }

  const startProcessing = async () => {
    setProcessing(true)
    setProcessingStep(0)

    // Simulate processing steps
    for (let i = 0; i < processingSteps.length; i++) {
      setProcessingStep(i)
      await new Promise((resolve) => setTimeout(resolve, 1500))
    }

    // Store the uploaded file data in sessionStorage for the results page
    if (uploadedFile) {
      sessionStorage.setItem("uploadedImage", uploadedFile.preview)
      sessionStorage.setItem("uploadedFileName", uploadedFile.file.name)
      sessionStorage.setItem("uploadedFileSize", (uploadedFile.file.size / 1024 / 1024).toFixed(2))
    }

    // Navigate to results page
    setTimeout(() => {
      router.push("/results")
    }, 1000)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800">
      {/* Navigation */}
      <nav className="border-b border-blue-500/20 bg-slate-900/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/" className="flex items-center space-x-2 text-blue-300 hover:text-blue-200">
                <ArrowLeft className="h-5 w-5" />
                <span>Back</span>
              </Link>
              <div className="flex items-center space-x-2">
                <Moon className="h-8 w-8 text-blue-400" />
                <span className="text-2xl font-bold text-white">LunarMapper</span>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        {!processing ? (
          <div className="max-w-4xl mx-auto space-y-8">
            <div className="text-center space-y-4">
              <h1 className="text-4xl font-bold text-white">Upload Lunar Image</h1>
              <p className="text-xl text-blue-200">Upload your lunar image and provide metadata for DEM generation</p>
            </div>

            <Tabs defaultValue="upload" className="w-full">
              <TabsList className="grid w-full grid-cols-2 bg-slate-800/50">
                <TabsTrigger value="upload" className="data-[state=active]:bg-blue-500/20">
                  Image Upload
                </TabsTrigger>
                <TabsTrigger value="metadata" disabled={!uploadedFile} className="data-[state=active]:bg-blue-500/20">
                  Metadata
                </TabsTrigger>
              </TabsList>

              <TabsContent value="upload" className="space-y-6">
                <Card className="bg-slate-800/50 border-blue-500/20">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Upload className="h-5 w-5" />
                      Upload Lunar Image
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div
                      className={`border-2 border-dashed rounded-lg p-12 text-center transition-colors ${
                        dragActive
                          ? "border-blue-400 bg-blue-500/10"
                          : "border-blue-500/30 hover:border-blue-400 hover:bg-blue-500/5"
                      }`}
                      onDragEnter={handleDrag}
                      onDragLeave={handleDrag}
                      onDragOver={handleDrag}
                      onDrop={handleDrop}
                    >
                      {uploadedFile ? (
                        <div className="space-y-4">
                          <img
                            src={uploadedFile.preview || "/placeholder.svg"}
                            alt="Uploaded lunar image"
                            className="max-w-md mx-auto rounded-lg"
                          />
                          <div className="space-y-2">
                            <p className="text-white font-medium">{uploadedFile.file.name}</p>
                            <p className="text-blue-200 text-sm">
                              {(uploadedFile.file.size / 1024 / 1024).toFixed(2)} MB
                            </p>
                            <Badge className="bg-green-500/20 text-green-300">
                              <CheckCircle className="h-4 w-4 mr-1" />
                              Image Loaded
                            </Badge>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          <Upload className="h-16 w-16 text-blue-400 mx-auto" />
                          <div>
                            <p className="text-xl text-white mb-2">Drag and drop your lunar image here</p>
                            <p className="text-blue-200 mb-4">Supports TMC, LRO NAC, and other lunar imagery formats</p>
                            <input
                              type="file"
                              accept="image/*"
                              onChange={handleFileInput}
                              className="hidden"
                              id="file-upload"
                            />
                            <label htmlFor="file-upload">
                              <Button className="bg-gradient-to-r from-blue-500 to-orange-500 hover:from-blue-600 hover:to-orange-600">
                                Choose File
                              </Button>
                            </label>
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="metadata" className="space-y-6">
                <Card className="bg-slate-800/50 border-blue-500/20">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Settings className="h-5 w-5" />
                      Image Metadata
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="solar-zenith" className="text-blue-200">
                          Solar Zenith Angle (degrees)
                        </Label>
                        <Input
                          id="solar-zenith"
                          placeholder="e.g., 45.5"
                          className="bg-slate-700/50 border-blue-500/30 text-white"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="solar-azimuth" className="text-blue-200">
                          Solar Azimuth Angle (degrees)
                        </Label>
                        <Input
                          id="solar-azimuth"
                          placeholder="e.g., 120.3"
                          className="bg-slate-700/50 border-blue-500/30 text-white"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="viewing-angle" className="text-blue-200">
                          Viewing Angle (degrees)
                        </Label>
                        <Input
                          id="viewing-angle"
                          placeholder="e.g., 15.2"
                          className="bg-slate-700/50 border-blue-500/30 text-white"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="mission" className="text-blue-200">
                          Mission/Instrument
                        </Label>
                        <Input
                          id="mission"
                          placeholder="e.g., LRO NAC"
                          className="bg-slate-700/50 border-blue-500/30 text-white"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="coordinates" className="text-blue-200">
                        Coordinates (Lat, Lon)
                      </Label>
                      <Input
                        id="coordinates"
                        placeholder="e.g., -23.4, 15.6"
                        className="bg-slate-700/50 border-blue-500/30 text-white"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="notes" className="text-blue-200">
                        Additional Notes
                      </Label>
                      <Textarea
                        id="notes"
                        placeholder="Any additional information about the image..."
                        className="bg-slate-700/50 border-blue-500/30 text-white"
                        rows={3}
                      />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>

            {uploadedFile && (
              <div className="text-center">
                <Button
                  size="lg"
                  onClick={startProcessing}
                  className="bg-gradient-to-r from-blue-500 to-orange-500 hover:from-blue-600 hover:to-orange-600 px-8 py-3"
                >
                  Generate DEM
                  <Zap className="ml-2 h-5 w-5" />
                </Button>
              </div>
            )}
          </div>
        ) : (
          <div className="max-w-2xl mx-auto space-y-8">
            <div className="text-center space-y-4">
              <h1 className="text-4xl font-bold text-white">Processing Your Image</h1>
              <p className="text-xl text-blue-200">AI is analyzing your lunar image and generating the DEM</p>
            </div>

            <Card className="bg-slate-800/50 border-blue-500/20">
              <CardContent className="p-8 space-y-6">
                <div className="space-y-4">
                  {processingSteps.map((step, index) => {
                    const Icon = step.icon
                    const isActive = index === processingStep
                    const isCompleted = index < processingStep

                    return (
                      <div
                        key={step.name}
                        className={`flex items-center space-x-4 p-4 rounded-lg transition-colors ${
                          isActive
                            ? "bg-blue-500/20 border border-blue-500/30"
                            : isCompleted
                              ? "bg-green-500/10 border border-green-500/20"
                              : "bg-slate-700/30"
                        }`}
                      >
                        <Icon
                          className={`h-6 w-6 ${
                            isActive ? "text-blue-400 animate-pulse" : isCompleted ? "text-green-400" : "text-slate-400"
                          }`}
                        />
                        <div className="flex-1">
                          <h3 className={`font-medium ${isActive || isCompleted ? "text-white" : "text-slate-400"}`}>
                            {step.name}
                          </h3>
                          <p
                            className={`text-sm ${
                              isActive ? "text-blue-200" : isCompleted ? "text-green-200" : "text-slate-500"
                            }`}
                          >
                            {step.description}
                          </p>
                        </div>
                        {isCompleted && <CheckCircle className="h-5 w-5 text-green-400" />}
                      </div>
                    )
                  })}
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-blue-200">Progress</span>
                    <span className="text-blue-200">
                      {Math.round((processingStep / processingSteps.length) * 100)}%
                    </span>
                  </div>
                  <Progress value={(processingStep / processingSteps.length) * 100} className="h-2 bg-slate-700" />
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
