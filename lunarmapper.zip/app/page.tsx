"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Upload, Zap, Globe, ArrowRight, Moon, Satellite, Brain } from "lucide-react"
import Link from "next/link"
import { Canvas } from "@react-three/fiber"
import { OrbitControls, Sphere, MeshDistortMaterial } from "@react-three/drei"
import { Suspense } from "react"

function MoonGlobe() {
  return (
    <Sphere args={[2, 100, 200]} scale={1}>
      <MeshDistortMaterial
        color="#4A90E2"
        attach="material"
        distort={0.3}
        speed={1.5}
        roughness={0.4}
        metalness={0.8}
      />
    </Sphere>
  )
}

export default function HomePage() {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800">
      {/* Navigation */}
      <nav className="border-b border-blue-500/20 bg-slate-900/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Moon className="h-8 w-8 text-blue-400" />
              <span className="text-2xl font-bold text-white">LunarMapper</span>
            </div>
            <div className="flex items-center space-x-6">
              <Link href="/process" className="text-blue-300 hover:text-blue-200 transition-colors">
                Upload
              </Link>
              <Link href="/gallery" className="text-blue-300 hover:text-blue-200 transition-colors">
                Gallery
              </Link>
              <Link href="/docs" className="text-blue-300 hover:text-blue-200 transition-colors">
                Docs
              </Link>
              <Button className="bg-gradient-to-r from-blue-500 to-orange-500 hover:from-blue-600 hover:to-orange-600">
                Get Started
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30">AI-Powered Lunar Analysis</Badge>
              <h1 className="text-5xl lg:text-6xl font-bold text-white leading-tight">
                Turn Shadows into{" "}
                <span className="bg-gradient-to-r from-blue-400 to-orange-400 bg-clip-text text-transparent">
                  Elevation
                </span>
              </h1>
              <p className="text-xl text-blue-200 leading-relaxed">
                High-Resolution Lunar DEMs from Single Images using advanced U-Net CNN architecture and photoclinometry
                techniques.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/process">
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-blue-500 to-orange-500 hover:from-blue-600 hover:to-orange-600 text-white px-8 py-3"
                  onMouseEnter={() => setIsHovered(true)}
                  onMouseLeave={() => setIsHovered(false)}
                >
                  Start Processing
                  <ArrowRight className={`ml-2 h-5 w-5 transition-transform ${isHovered ? "translate-x-1" : ""}`} />
                </Button>
              </Link>
              <Button
                variant="outline"
                size="lg"
                className="border-blue-500/30 text-blue-300 hover:bg-blue-500/10 bg-transparent"
              >
                View Demo
              </Button>
            </div>

            <div className="grid grid-cols-3 gap-6 pt-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-400">{"<1m"}</div>
                <div className="text-sm text-blue-200">Resolution</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-orange-400">{"<10min"}</div>
                <div className="text-sm text-blue-200">Processing</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-400">99%</div>
                <div className="text-sm text-blue-200">Accuracy</div>
              </div>
            </div>
          </div>

          <div className="relative h-96 lg:h-[500px]">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-orange-500/20 rounded-full blur-3xl"></div>
            <Canvas camera={{ position: [0, 0, 5] }}>
              <Suspense fallback={null}>
                <ambientLight intensity={0.5} />
                <pointLight position={[10, 10, 10]} />
                <MoonGlobe />
                <OrbitControls enableZoom={false} autoRotate autoRotateSpeed={1} />
              </Suspense>
            </Canvas>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">How LunarMapper Works</h2>
          <p className="text-xl text-blue-200 max-w-3xl mx-auto">
            Advanced AI pipeline transforms single lunar images into high-resolution elevation models
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          <Card className="bg-slate-800/50 border-blue-500/20 backdrop-blur-sm">
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Upload className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">Upload & Preprocess</h3>
              <p className="text-blue-200">
                Drag/drop lunar images with metadata. AI validates solar angles and geometry.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-orange-500/20 backdrop-blur-sm">
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-orange-500 to-orange-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Brain className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">U-Net CNN Processing</h3>
              <p className="text-blue-200">
                Deep learning analyzes shadows and brightness to extract elevation features.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-blue-500/20 backdrop-blur-sm">
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Globe className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">Generate DEM</h3>
              <p className="text-blue-200">Convert features to Digital Elevation Model with sub-pixel refinement.</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800/50 border-orange-500/20 backdrop-blur-sm">
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-orange-500 to-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Satellite className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">3D Visualization</h3>
              <p className="text-blue-200">Interactive Three.js models with downloadable GeoTIFF outputs.</p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Technology Stack */}
      <section className="container mx-auto px-4 py-20">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4">Powered by Advanced Technology</h2>
          <p className="text-xl text-blue-200">State-of-the-art AI and visualization technologies</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <Card className="bg-gradient-to-br from-blue-900/50 to-slate-800/50 border-blue-500/20">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-white mb-4">AI & Processing</h3>
              <ul className="space-y-2 text-blue-200">
                <li>• U-Net CNN Architecture</li>
                <li>• PyTorch Deep Learning</li>
                <li>• OpenCV Image Processing</li>
                <li>• Photoclinometry Algorithms</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-900/50 to-slate-800/50 border-orange-500/20">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-white mb-4">Visualization</h3>
              <ul className="space-y-2 text-blue-200">
                <li>• Three.js 3D Rendering</li>
                <li>• WebGL Acceleration</li>
                <li>• Interactive Terrain Models</li>
                <li>• Real-time Preview</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-900/50 to-orange-900/50 border-blue-500/20">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-white mb-4">Infrastructure</h3>
              <ul className="space-y-2 text-blue-200">
                <li>• AWS GPU Instances</li>
                <li>• GDAL Geospatial Tools</li>
                <li>• GeoTIFF Export</li>
                <li>• NASA PDS4 Compliance</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-20">
        <Card className="bg-gradient-to-r from-blue-900/50 to-orange-900/50 border-blue-500/20">
          <CardContent className="p-12 text-center">
            <h2 className="text-4xl font-bold text-white mb-4">Ready to Map the Moon?</h2>
            <p className="text-xl text-blue-200 mb-8 max-w-2xl mx-auto">
              Transform your lunar images into high-resolution elevation models with our AI-powered platform.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/process">
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-blue-500 to-orange-500 hover:from-blue-600 hover:to-orange-600 px-8 py-3"
                >
                  Start Processing Now
                  <Zap className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Button
                variant="outline"
                size="lg"
                className="border-blue-500/30 text-blue-300 hover:bg-blue-500/10 bg-transparent"
              >
                View Documentation
              </Button>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Footer */}
      <footer className="border-t border-blue-500/20 bg-slate-900/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Moon className="h-6 w-6 text-blue-400" />
              <span className="text-lg font-semibold text-white">LunarMapper</span>
            </div>
            <p className="text-blue-300">© 2024 LunarMapper. Advancing lunar science through AI.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
